<?php
    use Carbon\Carbon;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Estado de Cuenta - Banco <?php echo e($data['banco']['nombre']); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
        }
        h1, h2, h3 {
            color: #27548A;
        }
        .section {
            margin-bottom: 25px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        .resumen h2 {
            font-size: 18px;
            margin-bottom: 30px;
            text-align: center;
        }
        .resumen p{
            margin: 15px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .table th, .table td {
            border: 1px solid #ccc;
            padding: 5px;
            text-align: center;
            font-size: 10px;
        }
        .highlight {
            background-color: #27548A;
            color: white;
            padding: 5px 7px;
            border-radius: 5px;
        }
        .success { color: #0d7033; font-weight: bold; }
        .danger { color: #b61818; font-weight: bold; }
        .warning { color: #d46700; font-weight: bold; }
        .center { text-align: center; }
    </style>
</head>
<body>
    <h1 class="center">Estado de Cuenta del Banco</h1>

    <p><strong>Banco:</strong> <?php echo e($data['banco']['nombre']); ?></p>
    <p><strong>Cuenta:</strong> <?php echo e($data['banco']['cuenta']); ?> | <strong>CLABE:</strong> <?php echo e($data['banco']['clabe']); ?></p>
    <p><strong>Periodo:</strong> <?php echo e(Carbon::parse($data['periodo']['inicio'])->format('d/m/Y')); ?> al <?php echo e(Carbon::parse($data['periodo']['fin'])->format('d/m/Y')); ?></p>

    <div class="section">
        <h3>Movimientos Bancarios</h3>
        <?php if(count($data['movimientos']) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th>Monto</th>
                        <th>Método</th>
                        <th>Referencia</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['movimientos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Carbon::parse($mov['fecha'])->format('d/m/Y')); ?></td>
                            <td><?php echo e($mov['tipo_movimiento']); ?></td>
                            <td><?php echo e($mov['concepto']); ?></td>
                            <td>$<?php echo e(number_format($mov['monto'], 2)); ?></td>
                            <td><?php echo e($mov['metodo_pago']); ?></td>
                            <td><?php echo e($mov['referencia'] ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay movimientos registrados en este periodo.</p>
        <?php endif; ?>
    </div>

    <div class="section">
        <h3>Órdenes de Compra (Pagadas)</h3>
        <?php if(count($data['ordenes_compra']) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>No. OC</th>
                        <th>Artículo</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Método</th>
                        <th>Subtotal</th>
                        <th>Impuesto</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['ordenes_compra']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Carbon::parse($oc['created_at'])->format('d/m/Y')); ?></td>
                            <td><?php echo e($oc['numero_oc']); ?></td>
                            <td><?php echo e($oc['articulo']['nombre']); ?></td>
                            <td><?php echo e($oc['cantidad_articulo']); ?></td>
                            <td>$<?php echo e(number_format($oc['precio_articulo'], 2)); ?></td>
                            <td><?php echo e($oc['metodo_pago']); ?></td>
                            <td>$<?php echo e(number_format($oc['subtotal'], 2)); ?></td>
                            <td><?php echo e($oc['impuesto'] ? 'Sí' : 'No'); ?></td>
                            <td>$<?php echo e(number_format($oc['total'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay órdenes de compra pagadas en este periodo.</p>
        <?php endif; ?>
    </div>

    <div class="section">
        <h3>Gastos</h3>
        <?php if(count($data['gastos']) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Concepto</th>
                        <th>Método</th>
                        <th>Subtotal</th>
                        <th>Impuesto</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['gastos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Carbon::parse($gasto['created_at'])->format('d/m/Y')); ?></td>
                            <td><?php echo e($gasto['modulo_concepto']['nombre']); ?></td>
                            <td><?php echo e($gasto['metodo_pago']); ?></td>
                            <td>$<?php echo e(number_format($gasto['subtotal'], 2)); ?></td>
                            <td><?php echo e($gasto['impuesto'] ? 'Sí' : 'No'); ?></td>
                            <td>$<?php echo e(number_format($gasto['total'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay gastos en este periodo.</p>
        <?php endif; ?>
    </div>

    <div class="section">
        <h3>Ventas</h3>
        <?php if(count($data['ventas']) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Sucursal</th>
                        <th>Factura</th>
                        <th>Nota de crédito</th>
                        <th>Método de pago</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['ventas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Carbon::parse($venta['created_at'])->format('d/m/Y')); ?></td>
                            <td><?php echo e($venta['cotizacion']['sucursal']['nombre_empresa'] ?? $venta['cotizacion']['nombre_empresa'] ?? 'Sin sucursal'); ?></td>
                            <td><?php echo e($venta['numero_factura']); ?></td>
                            <td>$<?php echo e(number_format($venta['nota_credito'], 2)); ?></td>
                            <td><?php echo e($venta['metodo_pago']); ?></td>
                            <td>$<?php echo e(number_format($venta['total'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay ventas en este periodo.</p>
        <?php endif; ?>
    </div>

    <div class="section center resumen">
        <h2>Resumen Financiero</h2>
        <p><strong>Ingresos:</strong> <span class="success">$<?php echo e(number_format($data['resumen']['ingresos'], 2)); ?> MXN.</span></p>
        <p><strong>Egresos:</strong> <span class="danger">$<?php echo e(number_format($data['resumen']['egresos'], 2)); ?> MXN.</span></p>
        <p class="">
            <strong>Balance Final:</strong> <span class="highlight">$<?php echo e(number_format($data['resumen']['balance'], 2)); ?> MXN.</span>
        </p>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trabajo\proeje\backend\resources\views/pdf/estado_cuenta_banco.blade.php ENDPATH**/ ?>