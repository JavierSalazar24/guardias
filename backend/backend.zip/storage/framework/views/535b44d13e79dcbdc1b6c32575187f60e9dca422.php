<?php
    use Carbon\Carbon;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Estado de Cuenta - Proveedor <?php echo e($data['proveedor']['nombre_empresa']); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
        }
        h1, h2, h3 {
            color: #27548A;
        }
        .section {
            margin-bottom: 25px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        .title-orden{
            margin-top: 0;
            margin-bottom: 20px;
        }
        .text-provee{
            margin: 7px 0;
        }
        .resumen h3 {
            font-size: 20px;
            margin-bottom: 15px;
            text-align: center;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .table th, .table td {
            border: 0.5px solid #ccc;
            padding: 5px;
            text-align: center;
            font-size: 9px;
        }
        .highlight {
            background-color: #27548A;
            color: white;
            padding: 5px 7px;
            border-radius: 5px;
            display: inline-block;
            font-size: 15px;
        }
        .success {
            color: #0d7033;
            font-weight: bold;
        }
        .danger {
            color: #b61818;
            font-weight: bold;
        }
        .warning {
            color: #d46700;
            font-weight: bold;
        }
        .center {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center">Estado de Cuenta del Proveedor</h1>

    <p><strong>Proveedor:</strong> <?php echo e($data['proveedor']['nombre_empresa']); ?></p>
    <p><strong>Periodo:</strong> <?php echo e(Carbon::parse($data['periodo']['inicio'])->format('d/m/Y')); ?> al <?php echo e(Carbon::parse($data['periodo']['fin'])->format('d/m/Y')); ?></p>

    <div class="section">
        <h3 class="title-orden">Datos del Proveedor</h3>
        <p class="text-provee"><strong>RFC:</strong> <?php echo e($data['proveedor']['rfc']); ?></p>
        <p class="text-provee"><strong>Razón Social:</strong> <?php echo e($data['proveedor']['razon_social']); ?></p>
        <p class="text-provee"><strong>Dirección:</strong> <?php echo e($data['proveedor']['calle']); ?> <?php echo e($data['proveedor']['numero']); ?>, <?php echo e($data['proveedor']['colonia']); ?>, <?php echo e($data['proveedor']['municipio']); ?>, <?php echo e($data['proveedor']['estado']); ?>, CP: <?php echo e($data['proveedor']['cp']); ?>, <?php echo e($data['proveedor']['pais']); ?></p>
        <p class="text-provee"><strong>Teléfono Empresa:</strong> <?php echo e($data['proveedor']['telefono_empresa']); ?> Ext: <?php echo e($data['proveedor']['extension_empresa']); ?></p>
        <p class="text-provee"><strong>Contacto:</strong> <?php echo e($data['proveedor']['nombre_contacto']); ?> | <?php echo e($data['proveedor']['telefono_contacto']); ?> | WhatsApp: <?php echo e($data['proveedor']['whatsapp_contacto']); ?></p>
        <p class="text-provee"><strong>Correo:</strong> <?php echo e($data['proveedor']['correo']); ?></p>
        <p class="text-provee"><strong>Días de Crédito:</strong> <?php echo e($data['proveedor']['credito_dias'] ?? 'No definido'); ?></p>
    </div>

    <div class="section">
        <h3 class="title-orden">Órdenes de Compra</h3>
        <?php if(count($data['ordenes']) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th># OC</th>
                        <th>Fecha</th>
                        <th>Art.</th>
                        <th>Cant.</th>
                        <th>Precio U.</th>
                        <th>Subt.</th>
                        <th>Total</th>
                        <th>IVA</th>
                        <th>Pago</th>
                        <th>Banco</th>
                        <th>Estatus</th>
                        <th>Vencim.</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['ordenes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($orden['numero_oc']); ?></td>
                            <td><?php echo e($orden['fecha']); ?></td>
                            <td><?php echo e($orden['articulo']); ?></td>
                            <td><?php echo e($orden['cantidad']); ?></td>
                            <td>$<?php echo e(number_format($orden['precio'], 2)); ?></td>
                            <td>$<?php echo e(number_format($orden['subtotal'], 2)); ?></td>
                            <td>$<?php echo e(number_format($orden['total'], 2)); ?></td>
                            <td><?php echo e($orden['impuesto']); ?></td>
                            <td>
                                <?php if($orden['metodo_pago'] === 'Transferencia bancaria'): ?>
                                    Transferencia
                                <?php elseif($orden['metodo_pago'] === 'Tarjeta de crédito/débito'): ?>
                                    Tarjeta
                                <?php else: ?>
                                    <?php echo e($orden['metodo_pago']); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($orden['banco']); ?></td>
                            <td><?php echo e($orden['estatus']); ?></td>
                            <td><?php echo e($orden['fecha_vencimiento']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay órdenes de compra en este periodo.</p>
        <?php endif; ?>
    </div>

    <div class="section resumen">
        <h3 class="title-orden">Resumen General</h3>
        <ul>
            <li class="success">Pagadas: $<?php echo e(number_format($data['resumen']['pagadas'], 2)); ?> MXN.</li>
            <li class="danger">Pendientes: $<?php echo e(number_format($data['resumen']['pendientes'], 2)); ?> MXN.</li>
            <li class="danger">Vencidas: $<?php echo e(number_format($data['resumen']['vencidas'], 2)); ?> MXN.</li>
            <li class="warning">Canceladas: $<?php echo e(number_format($data['resumen']['canceladas'], 2)); ?> MXN.</li>
            <li><strong>Total de órdenes:</strong> $<?php echo e(number_format($data['resumen']['total'], 2)); ?> MXN.</li>
        </ul>
        <p class="center">
            <span class="highlight">Total por pagar (pendientes + vencidas): $<?php echo e(number_format($data['resumen']['por_pagar'], 2)); ?> MXN.</span>
        </p>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trabajo\proeje\backend\resources\views/pdf/estado_cuenta_proveedor.blade.php ENDPATH**/ ?>