<?php
    use Carbon\Carbon;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Estado de Cuenta - Cliente <?php echo e($data['cliente']['nombre_empresa']); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
        }
        h1, h2, h3 {
            color: #27548A;
        }
        .section {
            margin-bottom: 25px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        .resumen h2 {
            font-size: 20px;
            margin-bottom: 30px;
            text-align: center;
        }
        .sucursal-title {
            margin-top: 5px;
            font-size: 14px;
            font-weight: bold;
            color: #0d497f;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .table th, .table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: center;
        }
        .highlight {
            background-color: #27548A;
            color: white;
            padding: 5px 7px;
            border-radius: 5px;
        }
        .text-right {
            text-align: right;
        }
        .total-line {
            margin-top: 15px;
            border-top: 1px dashed #aaa;
            padding-top: 10px;
        }
        .success {
            color: #0d7033;
            font-weight: bold;
        }
        .danger {
            color: #b61818;
            font-weight: bold;
        }
        .warning{
            color: #d46700;
            font-weight: bold;
        }
        .datos-contacto{
            margin: 5px 0;
        }
        .info-extra {
            font-size: 11px;
            margin-top: 10px;
        }
        .info-extra p{
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center">Estado de Cuenta del Cliente</h1>

    <p><strong>Cliente:</strong> <?php echo e($data['cliente']['nombre_empresa']); ?></p>
    <p><strong>Periodo:</strong> <?php echo e(Carbon::parse($data['periodo']['inicio'])->format('d/m/Y')); ?> al <?php echo e(Carbon::parse($data['periodo']['fin'])->format('d/m/Y')); ?></p>

    <?php $__currentLoopData = $data['sucursales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="section">
            <p class="sucursal-title">Sucursal: <?php echo e($entry['sucursal']['nombre_empresa']); ?></p>
            <p class="datos-contacto"><strong>Dirección:</strong> <?php echo e($entry['sucursal']['calle']); ?> <?php echo e($entry['sucursal']['numero']); ?>, <?php echo e($entry['sucursal']['colonia']); ?>, <?php echo e($entry['sucursal']['municipio']); ?>, <?php echo e($entry['sucursal']['estado']); ?> CP: <?php echo e($entry['sucursal']['cp']); ?>, <?php echo e($entry['sucursal']['pais']); ?></p>
            <p class="datos-contacto"><strong>Teléfono:</strong> <?php echo e($entry['sucursal']['telefono_empresa']); ?> Ext: <?php echo e($entry['sucursal']['extension_empresa']); ?></p>
            <p class="datos-contacto"><strong>Contacto:</strong> <?php echo e($entry['sucursal']['nombre_contacto']); ?></p>

            <h3>Cotizaciones</h3>
            <?php if(count($entry['cotizaciones']) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Servicios</th>
                            <th>Guardias</th>
                            <th>Subtotal</th>
                            <th>Impuesto</th>
                            <th>Total</th>
                            <th>Aceptada</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $entry['cotizaciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(Carbon::parse($cot['fecha_servicio'])->format('d/m/Y')); ?></td>
                                <td><?php echo e($cot['servicios']); ?></td>
                                <td><?php echo e($cot['cantidad_guardias']); ?></td>
                                <td>$<?php echo e(number_format($cot['subtotal'], 2)); ?></td>
                                <td><?php echo e($cot['impuesto'] ? 'Sí' : 'No'); ?></td>
                                <td>$<?php echo e(number_format($cot['total'], 2)); ?></td>
                                <td><?php echo e($cot['aceptada']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="info-extra">
                    <p><strong>Jefe de turno:</strong> <?php echo e($cot['jefe_turno']); ?> <?php if($cot['jefe_turno'] === 'SI'): ?> - $<?php echo e(number_format($cot['precio_jefe_turno'], 2)); ?> <?php endif; ?></p>
                    <p><strong>Supervisor:</strong> <?php echo e($cot['supervisor']); ?> <?php if($cot['supervisor'] === 'SI'): ?> - $<?php echo e(number_format($cot['precio_supervisor'], 2)); ?> <?php endif; ?></p>
                    <p><strong>Requisitos de pago:</strong> <?php echo e($cot['requisitos_pago_cliente'] ?? 'No especificado'); ?></p>
                    <p><strong>Soporte documental:</strong> <?php echo e($cot['soporte_documental']); ?> <?php if(!empty($cot['observaciones_soporte_documental'])): ?> - <?php echo e($cot['observaciones_soporte_documental']); ?> <?php endif; ?></p>
                    <p><strong>Descuento:</strong> <?php echo e($cot['descuento_porcentaje'] ?? '0'); ?>%</p>
                    <p><strong>Costo extra:</strong> $<?php echo e($cot['costo_extra'] ?? '0'); ?></p>
                    <p><strong>Notas:</strong> <?php echo e($cot['notas'] ?? 'Sin notas adicionales'); ?></p>
                </div>
            <?php else: ?>
                <p>No hay cotizaciones en este periodo.</p>
            <?php endif; ?>

            <h3 style="margin-top: 20px">Ventas</h3>
            <?php if(count($entry['ventas']) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Factura</th>
                            <th>Emisión</th>
                            <th>Vencimiento</th>
                            <th>Días crédito</th>
                            <th>Nota crédito</th>
                            <th>Total</th>
                            <th>Tipo</th>
                            <th>Método</th>
                            <th>Estatus</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $entry['ventas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($venta['numero_factura'] ?? 'N/A'); ?></td>
                                <td><?php echo e(Carbon::parse($venta['fecha_emision'])->format('d/m/Y')); ?></td>
                                <td><?php echo e($venta['fecha_vencimiento'] ? Carbon::parse($venta['fecha_vencimiento'])->format('d/m/Y') : 'N/A'); ?></td>
                                <td><?php echo e($venta['tipo_pago'] === 'Crédito' ? ($venta['dias_credito'] ?? '-') : '-'); ?></td>
                                <td><?php echo e($venta['nota_credito']); ?></td>
                                <td>$<?php echo e(number_format($venta['total'], 2)); ?></td>
                                <td><?php echo e($venta['tipo_pago']); ?></td>
                                <td><?php echo e($venta['metodo_pago']); ?></td>
                                <td><?php echo e($venta['estatus']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay ventas en este periodo.</p>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="section resumen">
        <h2>Resumen General</h2>

        <div>
            <p>
                <strong>Totales de cotizaciones:</strong>
            </p>
            <ul>
                <li>Aceptadas: <?php echo e($data['resumen']['cotizaciones']['aceptadas']); ?></li>
                <li>No aceptadas: <?php echo e($data['resumen']['cotizaciones']['no_aceptadas']); ?></li>
                <li>Pendientes: <?php echo e($data['resumen']['cotizaciones']['pendientes']); ?></li>
            </ul>
        </div>

        <div class="total-line"></div>

        <div>
            <p>
                <strong>Total ventas:</strong> <span class="highlight">$<?php echo e(number_format($data['resumen']['ventas']['total'], 2)); ?></span>
            </p>
            <ul>
                <li class="success">Pagadas: $<?php echo e(number_format($data['resumen']['ventas']['pagadas'], 2)); ?></li>
                <li class="danger">Pendientes: $<?php echo e(number_format($data['resumen']['ventas']['pendientes'], 2)); ?></li>
                <li class="danger">Vencidas: $<?php echo e(number_format($data['resumen']['ventas']['vencidas'], 2)); ?></li>
                <li class="warning">Canceladas: $<?php echo e(number_format($data['resumen']['ventas']['canceladas'], 2)); ?></li>
            </ul>
        </div>

        <div class="total-line"></div>

        <div>
            <p>
                <strong>Balance financiero:</strong>
            </p>
            <ul>
                <li class="success">Total recibido (ventas pagadas): $<?php echo e(number_format($data['resumen']['ventas']['pagadas'], 2)); ?></li>
                <li class="danger">Total pendiente por pagar (pendientes + vencidas): $<?php echo e(number_format($data['resumen']['ventas']['pendientes'] + $data['resumen']['ventas']['vencidas'], 2)); ?></li>
            </ul>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trabajo\proeje\backend\resources\views/pdf/estado_cuenta_cliente.blade.php ENDPATH**/ ?>