<?php
    use Carbon\Carbon;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cotización de <?php echo e($cotizacion->nombre_empresa ?? $cotizacion->sucursal->nombre_empresa); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            color: #333;
            padding: 40px;
            line-height: 1.5;
        }
        h2, h3 {
            color: #1a3e72;
            text-align: center;
        }
        h2 {
            font-size: 22px;
        }
        h1 {
            margin: 0;
            margin-bottom: 20px;
            text-align: center;
        }
        .header, .section {
            margin-bottom: 30px;
        }
        .section{
            page-break-inside: avoid;
        }
        .info-box {
            background: #f1f5fb;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .label {
            font-weight: bold;
            color: #444;
        }
        .value {
            margin-bottom: 8px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 12px;
        }
        .table th, .table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: left;
        }
        .highlight {
            background: #1a3e72;
            color: white;
            font-weight: bold;
            text-align: right;
        }
    </style>
</head>
<body>
    <h1>Resumen de Cotización</h1>

    <div class="section">
        <h2>Datos del Cliente</h2>
        <div class="info-box">
            <?php if($cotizacion->sucursal): ?>
                <div class="value"><span class="label">Cliente:</span> <?php echo e($cotizacion->sucursal->cliente->nombre_empresa); ?></div>
                <div class="value"><span class="label">Sucursal:</span> <?php echo e($cotizacion->sucursal->nombre_empresa); ?></div>
                <div class="value"><span class="label">Contacto:</span> <?php echo e($cotizacion->sucursal->nombre_contacto); ?> | <?php echo e($cotizacion->sucursal->telefono_contacto); ?></div>
                <div class="value"><span class="label">Correo:</span> <?php echo e($cotizacion->sucursal->correo_contacto); ?></div>
                <div class="value"><span class="label">Dirección:</span> <?php echo e($cotizacion->sucursal->calle); ?> #<?php echo e($cotizacion->sucursal->numero); ?>, <?php echo e($cotizacion->sucursal->colonia); ?>, CP: <?php echo e($cotizacion->sucursal->cp); ?>, <?php echo e($cotizacion->sucursal->municipio); ?>, <?php echo e($cotizacion->sucursal->estado); ?>, <?php echo e($cotizacion->sucursal->pais); ?>.</div>
            <?php else: ?>
                <div class="value"><span class="label">Empresa:</span> <?php echo e($cotizacion->nombre_empresa); ?></div>
                <div class="value"><span class="label">Contacto:</span> <?php echo e($cotizacion->nombre_contacto); ?> | <?php echo e($cotizacion->telefono_contacto); ?></div>
                <div class="value"><span class="label">Correo:</span> <?php echo e($cotizacion->correo_contacto); ?></div>
                <div class="value"><span class="label">Dirección:</span> <?php echo e($cotizacion->calle); ?> #<?php echo e($cotizacion->numero); ?>, <?php echo e($cotizacion->colonia); ?>, CP: <?php echo e($cotizacion->cp); ?>, <?php echo e($cotizacion->municipio); ?>, <?php echo e($cotizacion->estado); ?>. <?php echo e($cotizacion->pais); ?>.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="section">
        <h2>Condiciones Comerciales</h2>
        <div class="info-box">
            <div class="value"><span class="label">Días de Crédito:</span> <?php echo e($cotizacion->credito_dias); ?></div>
            <?php if($cotizacion->sucursal): ?>
                <div class="value"><span class="label">Uso CFDI:</span> <?php echo e($cotizacion->sucursal->uso_cfdi); ?></div>
                <div class="value"><span class="label">Régimen Fiscal:</span> <?php echo e($cotizacion->sucursal->regimen_fiscal); ?></div>
                <div class="value"><span class="label">Razón social:</span> <?php echo e($cotizacion->sucursal->razon_social); ?></div>
                <div class="value"><span class="label">RFC:</span> <?php echo e($cotizacion->sucursal->rfc); ?></div>
            <?php else: ?>
                <div class="value"><span class="label">Uso CFDI:</span> <?php echo e($cotizacion->uso_cfdi); ?></div>
                <div class="value"><span class="label">Régimen Fiscal:</span> <?php echo e($cotizacion->regimen_fiscal); ?></div>
                <div class="value"><span class="label">Razón social:</span> <?php echo e($cotizacion->razon_social); ?></div>
                <div class="value"><span class="label">RFC:</span> <?php echo e($cotizacion->rfc); ?></div>
            <?php endif; ?>

        </div>
    </div>

    <div class="section">
        <h2>Servicio Cotizado</h2>
        <div class="info-box">
            <div class="value"><span class="label">Fecha del servicio:</span> <?php echo e(Carbon::parse($cotizacion->fecha_servicio)->format('d/m/Y')); ?></div>
            <div class="value"><span class="label">Servicios:</span> <?php echo e($cotizacion->servicios); ?></div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Cantidad</th>
                    <th>Precio unitario</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Guardias de día</td>
                    <td><?php echo e($cotizacion->guardias_dia); ?></td>
                    <td>$<?php echo e(number_format($cotizacion->precio_guardias_dia, 2)); ?> MXN.</td>
                    <td>$<?php echo e(number_format($cotizacion->precio_guardias_dia_total, 2)); ?> MXN.</td>
                </tr>
                <tr>
                    <td>Guardias de noche</td>
                    <td><?php echo e($cotizacion->guardias_noche); ?></td>
                    <td>$<?php echo e(number_format($cotizacion->precio_guardias_noche, 2)); ?> MXN.</td>
                    <td>$<?php echo e(number_format($cotizacion->precio_guardias_noche_total, 2)); ?> MXN.</td>
                </tr>
                <?php if($cotizacion->jefe_turno === 'SI'): ?>
                    <tr>
                        <td>Jefe de turno</td>
                        <td>1</td>
                        <td>$<?php echo e(number_format($cotizacion->precio_jefe_turno, 2)); ?> MXN.</td>
                        <td>$<?php echo e(number_format($cotizacion->precio_jefe_turno, 2)); ?> MXN.</td>
                    </tr>
                <?php endif; ?>
                <?php if($cotizacion->supervisor === 'SI'): ?>
                    <tr>
                        <td>Supervisor</td>
                        <td>1</td>
                        <td>$<?php echo e(number_format($cotizacion->precio_supervisor, 2)); ?> MXN.</td>
                        <td>$<?php echo e(number_format($cotizacion->precio_supervisor, 2)); ?> MXN.</td>
                    </tr>
                <?php endif; ?>
                <?php if($cotizacion->costo_extra): ?>
                    <tr>
                        <td>Otros Costos</td>
                        <td>1</td>
                        <td colspan="2">$<?php echo e(number_format($cotizacion->costo_extra, 2)); ?> MXN.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Total</h2>
        <table class="table">
            <tr>
                <td class="highlight">Subtotal</td>
                <td>
                    $<?php echo e(number_format($cotizacion->subtotal, 2)); ?> MXN.
                </td>
            </tr>
            <tr>
                <td class="highlight">Costo extra</td>
                <td>
                    $<?php echo e(number_format($cotizacion->costo_extra, 2)); ?> MXN.
                </td>
            </tr>
            <?php if($cotizacion->costo_extra): ?>
                <tr>
                    <td class="highlight">Subtotal ajustado</td>
                    <td>
                        $<?php echo e(number_format($cotizacion->subtotal + $cotizacion->costo_extra, 2)); ?> MXN.
                    </td>
                </tr>
            <?php endif; ?>
            <tr>
                <td class="highlight">Descuento</td>
                <td>
                    <?php if($cotizacion->descuento_porcentaje): ?>
                        <?php echo e($cotizacion->descuento_porcentaje); ?>%
                    <?php else: ?>
                        0%
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td class="highlight">Impuesto (IVA)</td>
                <td><?php echo e($cotizacion->impuesto); ?>%</td>
            </tr>
            <tr>
                <td class="highlight">Total</td>
                <td><strong>$<?php echo e(number_format($cotizacion->total, 2)); ?> MXN.</strong></td>
            </tr>
        </table>
    </div>

    <?php if($cotizacion->notas): ?>
    <div class="section">
        <h3>Notas Adicionales</h3>
        <div class="info-box">
            <?php echo e($cotizacion->notas); ?>

        </div>
    </div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\trabajo\proeje\backend\resources\views/pdf/cotizacion.blade.php ENDPATH**/ ?>