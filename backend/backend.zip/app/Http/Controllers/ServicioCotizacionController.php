<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServicioCotizacionController extends Controller
{
    //
}
