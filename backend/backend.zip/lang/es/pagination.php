<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Líneas de lenguaje de paginación
    |--------------------------------------------------------------------------
    |
    | Las siguientes líneas de lenguaje son utilizadas por la biblioteca
    | de paginación para construir los enlaces de paginación simples.
    | Puedes cambiarlas por lo que necesites para personalizar las vistas
    | de acuerdo a tu aplicación.
    |
    */

    'previous' => '&laquo; Anterior',
    'next' => 'Siguiente &raquo;',

];