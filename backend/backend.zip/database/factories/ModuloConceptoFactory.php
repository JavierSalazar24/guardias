<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ModuloConceptoFactory extends Factory
{
    protected $model = ModuloConcepto::class;

    public function definition()
    {

    }
}
