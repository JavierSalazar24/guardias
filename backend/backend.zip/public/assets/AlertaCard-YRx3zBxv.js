import{c,j as e}from"./index-Ci7g360f.js";/**
 * @license lucide-react v0.483.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],s=c("CircleAlert",t),l=({text:r})=>e.jsxs("div",{className:"bg-[#3674B5] font-semibold p-3 rounded-md text-white flex gap-1 items-center",children:[e.jsx(s,{}),e.jsx("h3",{children:r})]});export{l as A};
