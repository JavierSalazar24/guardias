function u(n,o){return typeof n=="function"?n(...o):!!n}function f(){}export{f as n,u as s};
